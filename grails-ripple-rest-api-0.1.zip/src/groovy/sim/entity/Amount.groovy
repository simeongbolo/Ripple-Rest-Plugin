package sim.entity
/**
 * Created by simeongbolo on 5/4/14.
 * Amount object used to map JSON requests
 */
class Amount {
    def value
    def currency
    def issuer
    def sourceCurrencies

}
