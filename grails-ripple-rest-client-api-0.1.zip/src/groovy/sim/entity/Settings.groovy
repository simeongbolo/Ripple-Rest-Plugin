package sim.entity

/**
 * Created by simeongbolo on 5/9/14.
 */
class Settings {

    def disable_master
    def disallow_xrp
    def password_spent
    def require_authorization
    def require_destination_tag
    def transaction_sequence
    def transfer_rate
    def domain
    def wallet_size
    def signers
    def wallet_locator
    def message_key
    def email_hash

}
