package sim.entity

/**
 * Created by simeongbolo on 5/9/14.
 */
class BalancesResponse {

    def balances
    def success

}
