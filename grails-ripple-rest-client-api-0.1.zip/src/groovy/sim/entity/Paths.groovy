package sim.entity

/**
 * Created by simeongbolo on 5/9/14.
 */
class Paths {

    def payments

}
