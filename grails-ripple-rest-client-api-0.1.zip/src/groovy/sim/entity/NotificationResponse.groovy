package sim.entity

/**
 * Created by simeongbolo on 5/9/14.
 */
class NotificationResponse {

    def account
    def type
    def direction
    def state
    def result
    def ledger
    def hash
    def timestamp
    def transaction_url
    def previous_hash
    def previous_notification_url
    def next_hash
    def next_notification_url
}
