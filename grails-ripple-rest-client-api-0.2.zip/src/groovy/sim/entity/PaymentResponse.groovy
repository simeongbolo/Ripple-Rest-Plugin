package sim.entity

/**
 * Created by simeongbolo on 5/9/14.
 */
class PaymentResponse {

    def client_resource_id
    def status_url
    def success

}
